using Microsoft.AspNetCore.Mvc;
using gamabelmvc.Models;
using gamabelmvc.Models.STS;
using gamabelmvc.Services;
using MySqlConnector;

namespace gamabelmvc.Controllers;

public class AdminController : Controller
{
    private readonly DbConnectionFactory _dbFactory;

    public AdminController(DbConnectionFactory dbFactory)
    {
        _dbFactory = dbFactory;
    }

    // Yetki kontrolü
    private bool IsAdmin()
    {
        var rol = HttpContext.Session.GetString("Rol") ?? "";
        return rol == "Admin";
    }

    // ========== ŞUBELERİ YÖNETİMİ ==========

    // GET: Admin/Subeler
    public async Task<IActionResult> Subeler()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            var subeler = new List<StsSube>();

            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureSubeResponsibleColumnAsync(conn);

                var query = @"SELECT s.*, k.AdSoyad as SorumluAdi
                              FROM stk_Sube s
                              LEFT JOIN stk_Kullanici k ON s.SorumluKullaniciId = k.Id
                              ORDER BY s.Ad";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            subeler.Add(new StsSube
                            {
                                Id = reader.GetInt32("Id"),
                                Ad = reader.GetString("Ad"),
                                Kod = reader.GetString("Kod"),
                                Tip = reader.GetString("Tip"),
                                AktifMi = reader.GetBoolean("AktifMi"),
                                SorumluKullaniciId = reader["SorumluKullaniciId"] == DBNull.Value ? null : Convert.ToInt32(reader["SorumluKullaniciId"]),
                                SorumluAdi = reader["SorumluAdi"] == DBNull.Value ? null : reader["SorumluAdi"]?.ToString()
                            });
                        }
                    }
                }

                var kullanicilar = new List<dynamic>();
                using (var userCmd = new MySqlCommand("SELECT Id, AdSoyad FROM stk_Kullanici WHERE AktifMi = true ORDER BY AdSoyad", conn))
                {
                    using (var reader = await userCmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            kullanicilar.Add(new { Id = reader.GetInt32("Id"), AdSoyad = reader.GetString("AdSoyad") });
                        }
                    }
                }
                ViewBag.Kullanicilar = kullanicilar;
            }

            return View("~/Views/STS/Admin/Subeler.cshtml", subeler);
        }
        catch (Exception ex)
        {
            return BadRequest($"Hata: {ex.Message}");
        }
    }

    [HttpPost]
    public async Task<IActionResult> SubeSorumluAta(int subeId, int? sorumluKullaniciId)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureSubeResponsibleColumnAsync(conn);
                using (var cmd = new MySqlCommand("UPDATE stk_Sube SET SorumluKullaniciId = @SorumluKullaniciId WHERE Id = @Id", conn))
                {
                    cmd.Parameters.AddWithValue("@Id", subeId);
                    cmd.Parameters.AddWithValue("@SorumluKullaniciId", sorumluKullaniciId.HasValue ? sorumluKullaniciId.Value : DBNull.Value);
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            TempData["Basari"] = "Şube sorumlusu güncellendi.";
            return RedirectToAction("Subeler");
        }
        catch (Exception ex)
        {
            TempData["Hata"] = $"Şube sorumlusu atanamadı: {ex.Message}";
            return RedirectToAction("Subeler");
        }
    }

    // GET: Admin/SubeEkle
    public IActionResult SubeEkle()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");
        return View("~/Views/STS/Admin/SubeEkle.cshtml", new StsSube());
    }

    // POST: Admin/SubeEkle
    [HttpPost]
    public async Task<IActionResult> SubeEkle(StsSube sube)
    {
        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                var query = @"
                    INSERT INTO stk_Sube (Ad, Kod, Tip, AktifMi)
                    VALUES (@Ad, @Kod, @Tip, @AktifMi)";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Ad", sube.Ad);
                    cmd.Parameters.AddWithValue("@Kod", sube.Kod);
                    cmd.Parameters.AddWithValue("@Tip", sube.Tip);
                    cmd.Parameters.AddWithValue("@AktifMi", sube.AktifMi);
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            return RedirectToAction("Subeler");
        }
        catch (Exception ex)
        {
            return BadRequest($"Hata: {ex.Message}");
        }
    }

    // ========== ÜRÜN YÖNETİMİ ==========

    // GET: Admin/Urunler
    public async Task<IActionResult> Urunler()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            var urunler = new List<StsUrun>();

            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureUrunKodColumnAsync(conn);
                await EnsureGrupColumnAsync(conn);

                var query = "SELECT Id, Kod, Ad, Barkod, Birim, Firma, Grup, AktifMi FROM stk_Urun ORDER BY Ad";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            urunler.Add(new StsUrun
                            {
                                Id = reader.GetInt32("Id"),
                                Kod = reader["Kod"] == DBNull.Value ? null : reader["Kod"]?.ToString(),
                                Ad = reader.GetString("Ad"),
                                Barkod = reader["Barkod"] == DBNull.Value ? null : reader["Barkod"]?.ToString(),
                                Birim = reader.GetString("Birim"),
                                Firma = reader["Firma"] == DBNull.Value ? null : reader["Firma"]?.ToString(),
                                Grup = reader["Grup"] == DBNull.Value ? null : reader["Grup"]?.ToString(),
                                AktifMi = reader.GetBoolean("AktifMi")
                            });
                        }
                    }
                }
            }

            return View("~/Views/STS/Admin/Urunler.cshtml", urunler);
        }
        catch (Exception ex)
        {
            return BadRequest($"Hata: {ex.Message}");
        }
    }

    // GET: Admin/UrunEkle
    public IActionResult UrunEkle()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");
        return View("~/Views/STS/Admin/UrunEkle.cshtml", new StsUrun());
    }

    // POST: Admin/UrunEkle
    [HttpPost]
    public async Task<IActionResult> UrunEkle(StsUrun urun)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        if (string.IsNullOrWhiteSpace(urun.Kod) || string.IsNullOrWhiteSpace(urun.Ad))
        {
            TempData["Hata"] = "Kod ve ürün adı zorunludur.";
            return RedirectToAction("UrunEkle");
        }

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureUrunKodColumnAsync(conn);

                var duplicateQuery = "SELECT COUNT(*) FROM stk_Urun WHERE Kod = @Kod";
                using (var duplicateCmd = new MySqlCommand(duplicateQuery, conn))
                {
                    duplicateCmd.Parameters.AddWithValue("@Kod", urun.Kod.Trim());
                    var exists = Convert.ToInt32(await duplicateCmd.ExecuteScalarAsync());
                    if (exists > 0)
                    {
                        TempData["Hata"] = "Bu ürün kodu zaten kayıtlı.";
                        return RedirectToAction("UrunEkle");
                    }
                }

                var query = @"
                    INSERT INTO stk_Urun (Kod, Ad, Barkod, Birim, AktifMi)
                    VALUES (@Kod, @Ad, @Barkod, @Birim, @AktifMi)";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Kod", urun.Kod.Trim());
                    cmd.Parameters.AddWithValue("@Ad", urun.Ad);
                    cmd.Parameters.AddWithValue("@Barkod", urun.Barkod ?? "");
                    cmd.Parameters.AddWithValue("@Birim", urun.Birim);
                    cmd.Parameters.AddWithValue("@AktifMi", urun.AktifMi);
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            TempData["Basari"] = "Ürün eklendi.";
            return RedirectToAction("Urunler");
        }
        catch (Exception ex)
        {
            TempData["Hata"] = $"Ürün eklenemedi: {ex.Message}";
            return RedirectToAction("UrunEkle");
        }
    }

    // GET: Admin/UrunTopluYukle
    public IActionResult UrunTopluYukle()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");
        return View("~/Views/STS/Admin/UrunTopluYukle.cshtml");
    }

    // POST: Admin/UrunTopluYukle
    [HttpPost]
    public async Task<IActionResult> UrunTopluYukle(IFormFile file)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        if (file == null || file.Length == 0)
        {
            TempData["Hata"] = "Lütfen bir Excel dosyası seçiniz.";
            return RedirectToAction("UrunTopluYukle");
        }

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (extension != ".xlsx" && extension != ".xls")
        {
            TempData["Hata"] = "Sadece Excel dosyaları (.xlsx, .xls) yüklenebilir.";
            return RedirectToAction("UrunTopluYukle");
        }

        var result = new UrunTopluYukleResult();
        
        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureUrunKodColumnAsync(conn);

                // MySQL'deki mevcut ürün sayısını al
                using (var countCmd = new MySqlCommand("SELECT COUNT(*) FROM stk_Urun", conn))
                {
                    result.MysqlUrunSayisi = Convert.ToInt32(await countCmd.ExecuteScalarAsync());
                }
            }

            // Placeholder: Excel toplu yükleme özelliği ürünlerin düzenle butonu ile eklenebilir
            result.ExcelSatirSayisi = 0;
            result.EklendiBayit = 0;
            result.Guncellenen = 0;
            result.Atlandi = 0;
            result.HataliSatir = 0;
            result.HataliSatirlar = new List<HataliUrunSatiri>
            {
                new HataliUrunSatiri 
                { 
                    SatirNumarasi = 1, 
                    Kod = "-", 
                    Ad = "-",
                    HataNedeni = "Excel import özelliği şu anda devre dışıdır. Lütfen ürünleri 'Düzenle' butonu ile ekleyiniz veya sistemi yönetici ile iletişime geçiniz."
                }
            };

            return View("~/Views/STS/Admin/UrunTopluYukle.cshtml", result);
        }
        catch (Exception ex)
        {
            TempData["Hata"] = $"Toplu yükleme hatası: {ex.Message}";
            return RedirectToAction("UrunTopluYukle");
        }
    }

    // ========== KULLANICI YÖNETİMİ ==========

    // GET: Admin/Kullanicilar
    public async Task<IActionResult> Kullanicilar()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            var kullanicilar = new List<dynamic>();

            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                var query = @"
                    SELECT k.*, s.Ad as SubeAdi
                    FROM stk_Kullanici k
                    JOIN stk_Sube s ON k.SubeId = s.Id
                    ORDER BY k.AdSoyad";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            kullanicilar.Add(new
                            {
                                Id = reader.GetInt32("Id"),
                                AdSoyad = reader.GetString("AdSoyad"),
                                KullaniciAdi = reader.GetString("KullaniciAdi"),
                                SubeAdi = reader.GetString("SubeAdi"),
                                Rol = reader.GetString("Rol"),
                                AktifMi = reader.GetBoolean("AktifMi")
                            });
                        }
                    }
                }
            }

            return View("~/Views/STS/Admin/Kullanicilar.cshtml", kullanicilar);
        }
        catch (Exception ex)
        {
            return BadRequest($"Hata: {ex.Message}");
        }
    }

    // GET: Admin/KullaniciEkle
    public async Task<IActionResult> KullaniciEkle()
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        using (var conn = await _dbFactory.CreateConnectionAsync())
        {
            var subeler = new List<StsSube>();
            using (var cmd = new MySqlCommand("SELECT Id, Ad FROM stk_Sube WHERE AktifMi = true ORDER BY Ad", conn))
            {
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        subeler.Add(new StsSube { Id = reader.GetInt32("Id"), Ad = reader.GetString("Ad") });
                    }
                }
            }
            ViewBag.Subeler = subeler;
        }

        return View("~/Views/STS/Admin/KullaniciEkle.cshtml", new StsKullanici());
    }

    // POST: Admin/KullaniciEkle
    [HttpPost]
    public async Task<IActionResult> KullaniciEkle(StsKullanici kullanici, string sifre)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        if (string.IsNullOrWhiteSpace(kullanici.AdSoyad) || string.IsNullOrWhiteSpace(kullanici.KullaniciAdi) || string.IsNullOrWhiteSpace(sifre))
        {
            TempData["Hata"] = "Ad Soyad, Kullanıcı Adı ve Şifre zorunludur.";
            return RedirectToAction("KullaniciEkle");
        }

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                // Kullanıcı adı benzersiz kontrolü
                var checkQuery = "SELECT COUNT(*) FROM stk_Kullanici WHERE KullaniciAdi = @KullaniciAdi";
                using (var checkCmd = new MySqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@KullaniciAdi", kullanici.KullaniciAdi);
                    var exists = Convert.ToInt32(await checkCmd.ExecuteScalarAsync());
                    if (exists > 0)
                    {
                        TempData["Hata"] = "Bu kullanıcı adı zaten kayıtlı.";
                        return RedirectToAction("KullaniciEkle");
                    }
                }

                var sifreHash = BCrypt.Net.BCrypt.HashPassword(sifre);
                var query = @"
                    INSERT INTO stk_Kullanici (SubeId, AdSoyad, KullaniciAdi, SifreHash, Rol, AktifMi)
                    VALUES (@SubeId, @AdSoyad, @KullaniciAdi, @SifreHash, @Rol, @AktifMi)";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SubeId", kullanici.SubeId);
                    cmd.Parameters.AddWithValue("@AdSoyad", kullanici.AdSoyad);
                    cmd.Parameters.AddWithValue("@KullaniciAdi", kullanici.KullaniciAdi);
                    cmd.Parameters.AddWithValue("@SifreHash", sifreHash);
                    cmd.Parameters.AddWithValue("@Rol", string.IsNullOrWhiteSpace(kullanici.Rol) ? "SubePersoneli" : kullanici.Rol);
                    cmd.Parameters.AddWithValue("@AktifMi", true);
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            TempData["Basari"] = "Kullanıcı başarıyla eklendi.";
            return RedirectToAction("Kullanicilar");
        }
        catch (Exception ex)
        {
            TempData["Hata"] = $"Kullanıcı ekleme hatası: {ex.Message}";
            return RedirectToAction("KullaniciEkle");
        }
    }

    // GET: Admin/KullaniciDuzenle/5
    public async Task<IActionResult> KullaniciDuzenle(int id)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        using (var conn = await _dbFactory.CreateConnectionAsync())
        {
            var model = new StsKullanici();

            var query = "SELECT Id, SubeId, AdSoyad, KullaniciAdi, Rol, AktifMi FROM stk_Kullanici WHERE Id = @Id";
            using (var cmd = new MySqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Id", id);
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (!await reader.ReadAsync())
                    {
                        TempData["Hata"] = "Kullanıcı bulunamadı.";
                        return RedirectToAction("Kullanicilar");
                    }

                    model.Id = reader.GetInt32("Id");
                    model.SubeId = reader.GetInt32("SubeId");
                    model.AdSoyad = reader.GetString("AdSoyad");
                    model.KullaniciAdi = reader.GetString("KullaniciAdi");
                    model.Rol = reader.GetString("Rol");
                    model.AktifMi = reader.GetBoolean("AktifMi");
                }
            }

            var subeler = new List<StsSube>();
            using (var cmd = new MySqlCommand("SELECT Id, Ad FROM stk_Sube WHERE AktifMi = true ORDER BY Ad", conn))
            {
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        subeler.Add(new StsSube { Id = reader.GetInt32("Id"), Ad = reader.GetString("Ad") });
                    }
                }
            }
            ViewBag.Subeler = subeler;

            return View("~/Views/STS/Admin/KullaniciDuzenle.cshtml", model);
        }
    }

    // POST: Admin/KullaniciDuzenle
    [HttpPost]
    public async Task<IActionResult> KullaniciDuzenle(StsKullanici kullanici, string? yeniSifre)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                var query = @"
                    UPDATE stk_Kullanici
                    SET SubeId = @SubeId,
                        AdSoyad = @AdSoyad,
                        Rol = @Rol,
                        AktifMi = @AktifMi
                    WHERE Id = @Id";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", kullanici.Id);
                    cmd.Parameters.AddWithValue("@SubeId", kullanici.SubeId);
                    cmd.Parameters.AddWithValue("@AdSoyad", kullanici.AdSoyad);
                    cmd.Parameters.AddWithValue("@Rol", kullanici.Rol);
                    cmd.Parameters.AddWithValue("@AktifMi", kullanici.AktifMi);
                    await cmd.ExecuteNonQueryAsync();
                }

                if (!string.IsNullOrWhiteSpace(yeniSifre))
                {
                    var sifreHash = BCrypt.Net.BCrypt.HashPassword(yeniSifre);
                    var sifreQuery = "UPDATE stk_Kullanici SET SifreHash = @SifreHash WHERE Id = @Id";
                    using (var cmd = new MySqlCommand(sifreQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", kullanici.Id);
                        cmd.Parameters.AddWithValue("@SifreHash", sifreHash);
                        await cmd.ExecuteNonQueryAsync();
                    }
                }
            }

            TempData["Basari"] = "Kullanıcı başarıyla güncellendi.";
            return RedirectToAction("Kullanicilar");
        }
        catch (Exception ex)
        {
            TempData["Hata"] = $"Kullanıcı güncelleme hatası: {ex.Message}";
            return RedirectToAction("Kullanicilar");
        }
    }

    // POST: Admin/KullaniciSil/5
    [HttpPost]
    public async Task<IActionResult> KullaniciSil(int id)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                var query = "DELETE FROM stk_Kullanici WHERE Id = @Id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            TempData["Basari"] = "Kullanıcı silindi.";
            return RedirectToAction("Kullanicilar");
        }
        catch (Exception ex)
        {
            TempData["Hata"] = $"Kullanıcı silme hatası: {ex.Message}";
            return RedirectToAction("Kullanicilar");
        }
    }

    private async Task EnsureUrunKodColumnAsync(MySqlConnection conn)
    {
        var columnExistsQuery = @"
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'stk_Urun'
              AND COLUMN_NAME = 'Kod';";

        using (var checkColumnCmd = new MySqlCommand(columnExistsQuery, conn))
        {
            var columnExists = Convert.ToInt32(await checkColumnCmd.ExecuteScalarAsync()) > 0;
            if (!columnExists)
            {
                var addColumnQuery = "ALTER TABLE stk_Urun ADD COLUMN Kod VARCHAR(50) NULL AFTER Id;";
                using (var addColumnCmd = new MySqlCommand(addColumnQuery, conn))
                {
                    await addColumnCmd.ExecuteNonQueryAsync();
                }
            }
        }

        var indexExistsQuery = @"
            SELECT COUNT(*)
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'stk_Urun'
              AND INDEX_NAME = 'uq_stk_urun_kod';";

        using (var checkIndexCmd = new MySqlCommand(indexExistsQuery, conn))
        {
            var indexExists = Convert.ToInt32(await checkIndexCmd.ExecuteScalarAsync()) > 0;
            if (!indexExists)
            {
                var addIndexQuery = "CREATE UNIQUE INDEX uq_stk_urun_kod ON stk_Urun(Kod);";
                using (var addIndexCmd = new MySqlCommand(addIndexQuery, conn))
                {
                    await addIndexCmd.ExecuteNonQueryAsync();
                }
            }
        }
    }

    private async Task EnsureGrupColumnAsync(MySqlConnection conn)
    {
        var columnExistsQuery = @"
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'stk_Urun'
              AND COLUMN_NAME = 'Grup';";

        using (var checkColumnCmd = new MySqlCommand(columnExistsQuery, conn))
        {
            var columnExists = Convert.ToInt32(await checkColumnCmd.ExecuteScalarAsync()) > 0;
            if (!columnExists)
            {
                var addColumnQuery = "ALTER TABLE stk_Urun ADD COLUMN Grup VARCHAR(100) NULL AFTER Firma;";
                using (var addColumnCmd = new MySqlCommand(addColumnQuery, conn))
                {
                    await addColumnCmd.ExecuteNonQueryAsync();
                }
            }
        }
    }

    private async Task EnsureSubeResponsibleColumnAsync(MySqlConnection conn)
    {
        var columnQuery = @"
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'stk_Sube'
              AND COLUMN_NAME = 'SorumluKullaniciId';";

        using (var cmd = new MySqlCommand(columnQuery, conn))
        {
            var exists = Convert.ToInt32(await cmd.ExecuteScalarAsync() ?? 0) > 0;
            if (!exists)
            {
                using (var alterCmd = new MySqlCommand("ALTER TABLE stk_Sube ADD COLUMN SorumluKullaniciId INT NULL AFTER AktifMi;", conn))
                {
                    await alterCmd.ExecuteNonQueryAsync();
                }
            }
        }
    }

    // GET: Admin/UrunDuzenle/{id}
    public async Task<IActionResult> UrunDuzenle(int id)
    {
        if (!IsAdmin()) return RedirectToAction("Index", "Home");

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureUrunKodColumnAsync(conn);
                await EnsureGrupColumnAsync(conn);

                var query = "SELECT Id, Kod, Ad, Barkod, Birim, Firma, Grup, AktifMi FROM stk_Urun WHERE Id = @Id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            var urun = new StsUrun
                            {
                                Id = reader.GetInt32("Id"),
                                Kod = reader["Kod"] == DBNull.Value ? null : reader["Kod"]?.ToString(),
                                Ad = reader.GetString("Ad"),
                                Barkod = reader["Barkod"] == DBNull.Value ? null : reader["Barkod"]?.ToString(),
                                Birim = reader.GetString("Birim"),
                                Firma = reader["Firma"] == DBNull.Value ? null : reader["Firma"]?.ToString(),
                                Grup = reader["Grup"] == DBNull.Value ? null : reader["Grup"]?.ToString(),
                                AktifMi = reader.GetBoolean("AktifMi")
                            };
                            return Json(urun);
                        }
                    }
                }
            }
            return Json(new { error = "Ürün bulunamadı." });
        }
        catch (Exception ex)
        {
            return Json(new { error = ex.Message });
        }
    }

    // POST: Admin/UrunGuncelle
    [HttpPost]
    public async Task<IActionResult> UrunGuncelle(int id, string kod, string ad, string barkod, string birim, string firma, string grup, bool aktifMi)
    {
        if (!IsAdmin()) return Unauthorized();

        if (string.IsNullOrWhiteSpace(ad) || string.IsNullOrWhiteSpace(birim))
            return Json(new { success = false, message = "Ürün adı ve birim zorunludur." });

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                await EnsureUrunKodColumnAsync(conn);
                await EnsureGrupColumnAsync(conn);

                var query = "UPDATE stk_Urun SET Kod = @Kod, Ad = @Ad, Barkod = @Barkod, Birim = @Birim, Firma = @Firma, Grup = @Grup, AktifMi = @AktifMi WHERE Id = @Id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@Kod", string.IsNullOrWhiteSpace(kod) ? (object)DBNull.Value : kod);
                    cmd.Parameters.AddWithValue("@Ad", ad);
                    cmd.Parameters.AddWithValue("@Barkod", string.IsNullOrWhiteSpace(barkod) ? (object)DBNull.Value : barkod);
                    cmd.Parameters.AddWithValue("@Birim", birim);
                    cmd.Parameters.AddWithValue("@Firma", string.IsNullOrWhiteSpace(firma) ? (object)DBNull.Value : firma);
                    cmd.Parameters.AddWithValue("@Grup", string.IsNullOrWhiteSpace(grup) ? (object)DBNull.Value : grup);
                    cmd.Parameters.AddWithValue("@AktifMi", aktifMi);
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            return Json(new { success = true, message = "Ürün başarıyla güncellendi." });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = $"Hata: {ex.Message}" });
        }
    }

    // POST: Admin/SilUrun
    [HttpPost]
    public async Task<IActionResult> SilUrun(int id)
    {
        if (!IsAdmin()) return Unauthorized();

        try
        {
            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                var query = "DELETE FROM stk_Urun WHERE Id = @Id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    var rowsAffected = await cmd.ExecuteNonQueryAsync();
                    
                    if (rowsAffected == 0)
                        return Json(new { success = false, message = "Ürün bulunamadı." });
                }
            }

            return Json(new { success = true, message = "Ürün başarıyla silindi." });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = $"Hata: {ex.Message}" });
        }
    }
}
