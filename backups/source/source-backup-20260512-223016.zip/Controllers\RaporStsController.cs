using Microsoft.AspNetCore.Mvc;
using gamabelmvc.Services;
using MySqlConnector;

namespace gamabelmvc.Controllers;

public class RaporStsController : Controller
{
    private readonly DbConnectionFactory _dbFactory;

    public RaporStsController(DbConnectionFactory dbFactory)
    {
        _dbFactory = dbFactory;
    }

    // GET: Rapor/Index - Eksik trendi, geç giren şubeler, en çok eksik ürün
    public async Task<IActionResult> Index()
    {
        try
        {
            var raporData = new Dictionary<string, object>();
            var haftaNo = GetHaftaNo();

            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                // 1. En çok eksik ürün
                var enCokEksikUrunler = new List<dynamic>();
                using (var cmd = new MySqlCommand(@"
                    SELECT u.Ad, u.Birim, COUNT(*) as Adet
                    FROM stk_EksikKaydi e
                    JOIN stk_Urun u ON e.UrunId = u.Id
                    WHERE e.HaftaNo = @HaftaNo
                    GROUP BY u.Id, u.Ad, u.Birim
                    ORDER BY Adet DESC
                    LIMIT 10", conn))
                {
                    cmd.Parameters.AddWithValue("@HaftaNo", haftaNo);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            enCokEksikUrunler.Add(new
                            {
                                UrunAdi = reader.GetString("Ad"),
                                Birim = reader["Birim"] == DBNull.Value ? string.Empty : reader["Birim"]?.ToString() ?? string.Empty,
                                Adet = reader.GetInt32("Adet")
                            });
                        }
                    }
                }
                raporData["EnCokEksikUrunler"] = enCokEksikUrunler;

                // 2. Geç giren şubeler (Pazartesi kapanışından sonra giren)
                var gecGirenSubeler = new List<dynamic>();
                using (var cmd = new MySqlCommand(@"
                    SELECT s.Ad, COUNT(*) as Adet, MAX(e.GirisTarihi) as SonGirisTarihi
                    FROM stk_EksikKaydi e
                    JOIN stk_Sube s ON e.SubeId = s.Id
                    WHERE e.HaftaNo = @HaftaNo
                    GROUP BY s.Id
                    ORDER BY Adet DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@HaftaNo", haftaNo);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            gecGirenSubeler.Add(new
                            {
                                SubeAdi = reader.GetString("Ad"),
                                EksikSayisi = reader.GetInt32("Adet"),
                                SonGirisTarihi = Convert.ToDateTime(reader["SonGirisTarihi"])
                            });
                        }
                    }
                }
                raporData["GecGirenSubeler"] = gecGirenSubeler;

                // 3. Eksik trendi (Haftalık)
                var eksikTrendi = new List<dynamic>();
                using (var cmd = new MySqlCommand(@"
                    SELECT HaftaNo, COUNT(*) as ToplamEksik
                    FROM stk_EksikKaydi
                    GROUP BY HaftaNo
                    ORDER BY HaftaNo DESC
                    LIMIT 13", conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            eksikTrendi.Add(new
                            {
                                HaftaNo = reader.GetString("HaftaNo"),
                                ToplamEksik = reader.GetInt32("ToplamEksik")
                            });
                        }
                    }
                }
                raporData["EksikTrendi"] = eksikTrendi;

                // 4. Acil eksiklerin durumu
                var acilEksikler = new List<dynamic>();
                using (var cmd = new MySqlCommand(@"
                    SELECT s.Ad, u.Ad as UrunAdi, u.Birim, e.Miktar, e.Durum
                    FROM stk_EksikKaydi e
                    JOIN stk_Sube s ON e.SubeId = s.Id
                    JOIN stk_Urun u ON e.UrunId = u.Id
                    WHERE e.HaftaNo = @HaftaNo AND e.AcilMi = true
                    ORDER BY e.GirisTarihi DESC", conn))
                {
                    cmd.Parameters.AddWithValue("@HaftaNo", haftaNo);
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            acilEksikler.Add(new
                            {
                                SubeAdi = reader.GetString("Ad"),
                                UrunAdi = reader.GetString("UrunAdi"),
                                Birim = reader["Birim"] == DBNull.Value ? string.Empty : reader["Birim"]?.ToString() ?? string.Empty,
                                Miktar = reader.GetDecimal("Miktar"),
                                Durum = reader.GetString("Durum")
                            });
                        }
                    }
                }
                raporData["AcilEksikler"] = acilEksikler;
            }

            ViewBag.RaporData = raporData;
            ViewBag.HaftaNo = haftaNo;
            return View("~/Views/STS/RaporSts/Index.cshtml", raporData);
        }
        catch (Exception ex)
        {
            return BadRequest($"Hata: {ex.Message}");
        }
    }

    // GET: Rapor/GeçmisHareketler - Tüm kayıtların logu (düzeltmeler + kim yaptı)
    public async Task<IActionResult> GeçmisHareketler()
    {
        try
        {
            var hareketler = new List<dynamic>();

            using (var conn = await _dbFactory.CreateConnectionAsync())
            {
                var query = @"
                    SELECT hl.*, k.AdSoyad
                    FROM stk_HareketLog hl
                    JOIN stk_Kullanici k ON hl.YapanKullaniciId = k.Id
                    ORDER BY hl.IslemTarihi DESC
                    LIMIT 1000";

                using (var cmd = new MySqlCommand(query, conn))
                {
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            hareketler.Add(new
                            {
                                Id = reader.GetInt32("Id"),
                                TabloAdi = reader.GetString("TabloAdi"),
                                KayitId = reader.GetInt32("KayitId"),
                                IslemTipi = reader.GetString("IslemTipi"),
                                YapanKullanici = reader.GetString("AdSoyad"),
                                IslemTarihi = Convert.ToDateTime(reader["IslemTarihi"]),
                                EskiDeger = reader["EskiDeger"] == DBNull.Value ? null : reader["EskiDeger"]?.ToString(),
                                YeniDeger = reader["YeniDeger"] == DBNull.Value ? null : reader["YeniDeger"]?.ToString()
                            });
                        }
                    }
                }
            }

            return View("~/Views/STS/RaporSts/GeçmisHareketler.cshtml", hareketler);
        }
        catch (Exception ex)
        {
            return BadRequest($"Hata: {ex.Message}");
        }
    }

    private string GetHaftaNo()
    {
        var today = DateTime.Now;
        var cultureInfo = System.Globalization.CultureInfo.GetCultureInfo("tr-TR");
        var weekOfYear = cultureInfo.Calendar.GetWeekOfYear(today, System.Globalization.CalendarWeekRule.FirstFullWeek, DayOfWeek.Monday);
        return $"{today.Year}-W{weekOfYear:D2}";
    }
}
