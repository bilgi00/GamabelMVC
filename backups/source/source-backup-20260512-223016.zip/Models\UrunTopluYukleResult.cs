namespace gamabelmvc.Models;

public class UrunTopluYukleResult
{
    public int EklendiBayit { get; set; }
    public int Guncellenen { get; set; }
    public int Atlandi { get; set; }
    public int HataliSatir { get; set; }
    public int ExcelSatirSayisi { get; set; }
    public int MysqlUrunSayisi { get; set; }
    public List<HataliUrunSatiri> HataliSatirlar { get; set; } = new List<HataliUrunSatiri>();
}

public class HataliUrunSatiri
{
    public int SatirNumarasi { get; set; }
    public string Kod { get; set; }
    public string Ad { get; set; }
    public string HataNedeni { get; set; }
}
