# Gamabel MVC - Depo ve Sevkiyat Yönetim Sistemi

## 📋 Proje Özeti

**Gamabel MVC**, iki ayrı modülle çalışan kapsamlı bir yönetim sistemidir:

1. **Personel Modülü**: Şirket personelinin yönetimi (görevlendirilmiş modül)
2. **STS Modülü** (Sevkiyat Takip Sistemi): Ana depo ve şubeler arası sevkiyat, eksik yönetimi, fabrika sipariş takibi

---

## 🏗️ Sistem Mimarisi

### Teknoloji Stack
- **Framework**: ASP.NET Core 9.0
- **Veritabanı**: MySQL (Türkçe karakter desteği - utf8mb4_turkish_ci)
- **ORM**: Manual SQL Queries with MySqlConnector
- **Frontend**: Bootstrap 5, Razor Views
- **Excel**: EPPlus 7.0.7
- **Güvenlik**: BCrypt.Net-Next (Şifre hashing)

### Proje Yapısı
```
gamabelmvc/
├── Controllers/          # İş mantığı
├── Views/
│   ├── Account/         # Giriş sayfaları
│   ├── STS/             # STS modülü (Sevkiyat, Eksik, vb.)
│   └── Shared/          # Ortak layout
├── Models/
│   ├── STS/             # STS veri modelleri
│   └── *.cs             # Diğer modeller
├── Services/            # DbConnectionFactory
├── sql/                 # Veritabanı şemaları
├── wwwroot/             # Statik dosyalar
└── Program.cs           # Startup configuration
```

---

## 🗄️ Veritabanı Şeması (STS Modülü)

### Ana Tablolar

#### 1. **stk_Sube** - Şubeler/Lokasyonlar
```sql
- Id (PK)
- Ad (String, 100) - Şube adı
- Kod (String, 10) - Unique kod
- Tip (Enum) - 'Sube' | 'AnaDepo'
- AktifMi (Boolean)
- SorumluKullaniciId (FK) - İlgili sorumlu
```

#### 2. **stk_Urun** - Ürünler Kataloğu
```sql
- Id (PK)
- Ad (String, 200)
- Barkod (String, 50) - Unique
- Birim (String, 20) - Varsayılan: 'Adet'
- Firma (String) - Ürün tedarikçisi
- AktifMi (Boolean)
```

#### 3. **stk_Kullanici** - Sistem Kullanıcıları
```sql
- Id (PK)
- SubeId (FK) - Ait olduğu şube
- AdSoyad (String, 100)
- KullaniciAdi (String, 50) - Unique
- SifreHash (String, 255) - BCrypt
- Rol (Enum) - 'SubePersoneli' | 'DepoSorumlusu' | 'Admin'
- SonGirisTarihi (DateTime)
- AktifMi (Boolean)
```

#### 4. **stk_EksikKaydi** - Eksik Kayıtları
```sql
- Id (PK)
- SubeId (FK) - Eksik olan şube
- UrunId (FK)
- Miktar (Decimal, 10,2)
- AcilMi (Boolean) - Acil mi?
- SiparisNo (String) - Sipariş referansı
- GeciktiMi (Boolean) - Pazartesi 17:00 sonrası girildi mi?
- Durum (Enum) - 'Bekliyor' | 'SevkEdildi' | 'Tamamlandi'
- HaftaNo (String) - Haftanın numarası
- GirisTarihi (DateTime)
- GirisiYapanKullaniciId (FK)
- Unique Constraint: (HaftaNo, SubeId, UrunId)
```

#### 5. **stk_Sevkiyat** - Sevkiyat İşlemleri
```sql
- Id (PK)
- EksikKaydiId (FK)
- SevkMiktari (Decimal, 10,2)
- SevkTarihi (DateTime) - Depodan çıkış
- SevkedenKullaniciId (FK)
- Durum (Enum) - 'Hazirlaniyor' | 'Yolda' | 'TeslimEdildi' | 'OnayBekliyor' | 'Onaylandi'
- SubeOnayTarihi (DateTime) - Şube teslim aldığında
- SubeOnayNotu (String, 500)
```

#### 6. **stk_FabrikaSiparisi** - Fabrika Siparişleri
```sql
- Id (PK)
- UrunId (FK)
- Miktar (Decimal, 10,2)
- HaftaNo (String)
- SiparisTarihi (DateTime)
- Durum (Enum) - 'SiparisVerildi' | 'Uretimde' | 'Yolda' | 'TeslimAlindi'
- TahminiTeslimTarihi (Date)
- Not (String, 500)
- KaynakSevkiyatId (FK) - Hangi sevkiyattan oluştu (nullable)
```

#### 7. **stk_HareketLog** - Audit Log
```sql
- Id (PK)
- TabloAdi (String)
- KayitId (Int)
- EskiDeger (Text) - JSON
- YeniDeger (Text) - JSON
- IslemTipi (Enum) - 'Ekle' | 'Guncelle' | 'Sil' | 'Duzeltme'
- YapanKullaniciId (FK)
- IslemTarihi (DateTime)
- IpAdres (String)
```

#### 8. **stk_HaftaKapanis** - Hafta Kapanış Takibi
```sql
- Id (PK)
- HaftaNo (String) - Unique
- PazartesiTarihi (Date)
- EksikGirisKapandiMi (Boolean)
- GecGirenSubeler (JSON) - Pazartesi 17:00 sonrası giren şubeler
```

#### 9. **stk_Bildirim** - Sistem Bildirimleri
```sql
- Id (PK)
- HedefRol (String) - 'DepoSorumlusu' | 'SubePersoneli' | 'Admin'
- HedefSubeId (FK)
- Baslik (String)
- Mesaj (String)
- Link (String)
- OkunduMu (Boolean)
- OlusturmaTarihi (DateTime)
```

---

## 🔐 Rol ve Yetki Sistemi

### Rol Türleri (STS Modülü)

#### 1. **SubePersoneli** (Şube Personeli)
- **Erişim**: Kendi şubesine ait işlemler
- **İzinler**:
  - Eksik kaydı giremez (sadece depo giriş yapar)
  - Gelen sevkiyatları onaylar/reddeder
  - Kendi sevkiyat geçmişini görür

#### 2. **DepoSorumlusu** (Ana Depo Sorumlusu)
- **Erişim**: Tüm şubeler ve sevkiyat işlemleri
- **İzinler**:
  - Eksik kayıtlarını görür ve yönetir
  - Sevkiyat çıkışı yapar
  - Fabrika siparişi oluşturur
  - Eksik listesini Excel'e aktarır

#### 3. **Admin** (Sistem Yöneticisi)
- **Erişim**: Tüm sistem
- **İzinler**:
  - Şubeleri yönetir
  - Ürünleri yönetir (toplu yükleme)
  - Kullanıcıları yönetir
  - Tüm raporları görür
  - Audit log'ları görür

---

## 📱 Controller ve View Haritası

### STS Modülü Controllers

#### 1. **AccountController**
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| Login | GET/POST | STS kullanıcı girişi (Session) |
| StsLogin | GET/POST | STS giriş formu |
| Logout | GET | Oturumu kapat |

#### 2. **HomeController**
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| Index | GET | Ana sayfa (Rol kontrolü) |

#### 3. **EksikController** - Eksik Kayıt Yönetimi
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| SubeListe | GET | Şubenin eksiklerini göster |
| Create | GET/POST | Yeni eksik kaydı ekle |
| UrunAra | GET (AJAX) | Ürün adıyla arama (autocomplete) |
| BarkodAra | GET (AJAX) | Barkod ile ürün arama |
| TopluKaydet | POST | Toplu eksik kaydı |
| Gecmis | GET | Eksik geçmişi |

#### 4. **SevkiyatController** - Sevkiyat Yönetimi
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| Index | GET | Sevk bekleyen eksikleri listele |
| SevkEt | POST | Eksik kaydını sevk et (Depo) |
| SubeOnay | GET | Şube gelen sevkiyatları göster |
| OnayEt | POST | Sevkiyatı onayla (Şube) |
| Reddet | POST | Sevkiyatı reddet (Şube) |
| ExportBekleyenEksikler | GET | Excel'e aktar |

#### 5. **SiparisController** - Fabrika Siparişleri
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| FabrikaListe | GET | Fabrika siparişleri listesi |
| Durumlar | GET | Durum değiştir |
| PDF | GET | PDF çıktısı |
| EksikKaydidenSiparisTur | POST | Eksikten fabrika siparişi yarat |

#### 6. **RaporStsController** - Raporlama
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| Index | GET | Eksik trendi ve istatistikler |
| EnCokEksikUrunler | JSON | Top 10 eksik ürün |
| GecGirenSubeler | JSON | Geç giren şubeler |
| EksikTrendi | JSON | Haftalık trend |

#### 7. **AdminController** - Admin İşlemleri
| Aksiyon | Metot | Açıklama |
|---------|-------|---------|
| Subeler | GET | Şubeleri listele ve yönet |
| Urunler | GET | Ürünleri listele ve yönet |
| Kullanicilar | GET | Kullanıcıları yönet |
| TopluUrunYukle | POST | Ürün CSV/Excel yükle |

---

## 📊 Veri Akışı (Şematik)

### Eksik Kaydı → Sevkiyat → Onay Süreci

```
1. EKSIK KAYDI (Şube personeli)
   └─> stk_EksikKaydi (Durum: 'Bekliyor')
   └─> Depo Sorumlusuna bildirim

2. SEVK ÇIKIŞI (Depo Sorumlusu)
   └─> stk_Sevkiyat oluştur (Durum: 'Yolda')
   └─> stk_EksikKaydi.Durum = 'SevkEdildi'
   └─> Şubeye bildirim gönder

3. ONAY (Şube Personeli)
   ├─> ONAYLA
   │   └─> stk_Sevkiyat.Durum = 'Onaylandi'
   │   └─> stk_EksikKaydi.Durum = 'Tamamlandi'
   │
   └─> REDDET
       └─> stk_Sevkiyat.Durum = 'IadeEdildi'
       └─> stk_EksikKaydi.Durum = 'Bekliyor'
       └─> Depo Sorumlusuna bildirim
```

### Fabrika Sipariş Akışı

```
Eksik Kaydı → Fabrika Siparişine Dönüştür
└─> stk_FabrikaSiparisi.KaynakSevkiyatId = Sevkiyat ID
└─> Durum: 'SiparisVerildi' → 'Uretimde' → 'Yolda' → 'TeslimAlindi'
```

---

## 🔑 Önemli Business Logic

### Hafta Numaralandırması
- **Format**: "Wnn" (örn: "W20" = 20. hafta)
- **Pazartesi 17:00 Kuralı**: 
  - Pazartesi 17:00 öncesi giriş = Zamanında
  - Pazartesi 17:00 sonrası giriş = Gecikti (İşaretlenir)
- **Method**: `GetHaftaNo()` - ISO 8601 hafta numarasına göre

### Session Yönetimi
```
Session Keys:
- ActiveModule: "STS" | "Personel"
- KullaniciId: Int32
- SubeId: Int32
- KullaniciAdi: String
- Rol: String
```

### Excel Export
- **Dosya Format**: .xlsx (Office Open XML)
- **Kütüphane**: EPPlus 7.0.7
- **LicenseContext**: NonCommercial
- **İçerik**: Sevk bekleyen eksikler (Filtrelenebilir)
- **Sütunlar**: Sipariş No, Ürün, Şube, Firma, Miktar, Acil, Gecikti, Tarih

---

## 🚀 Kurulum ve Çalıştırma

### Ön Gereksinimler
- .NET 9.0 SDK
- MySQL Server (Türkçe karakter desteği ile)
- Visual Studio Code / Visual Studio 2022

### Adım 1: Veritabanı Kurulumu
```bash
# MySQL'de veritabanı oluştur
mysql -u root -p
> CREATE DATABASE u2636310_dbE97 
  CHARACTER SET utf8mb4 
  COLLATE utf8mb4_turkish_ci;

# SQL script'ini çalıştır
mysql -u u2636310_userE97 -p u2636310_dbE97 < sqltasarim_sts.sql
```

### Adım 2: Bağlantı Dizesi Ayarı
**appsettings.json** dosyasını düzenle:
```json
{
  "ConnectionStrings": {
    "MyConnection": "Server=localhost;Database=u2636310_dbE97;User=u2636310_userE97;Password=VQLjJ1hmp3VdOQTp;SslMode=Preferred;"
  }
}
```

### Adım 3: Projeyi Derle ve Çalıştır
```bash
cd e:\gamabelmvc

# NuGet paketlerini geri yükle
dotnet restore

# Projeyi derle
dotnet build

# Uygulamayı çalıştır
dotnet run
```

**Sunucu başarılı başlarsa**: http://localhost:5010

---

## 📦 Bağımlılıklar (NuGet Packages)

| Paket | Versiyon | Kullanım |
|-------|----------|---------|
| MySqlConnector | 2.5.0 | Veritabanı bağlantısı |
| BCrypt.Net-Next | 4.0.3 | Şifre hashing |
| EPPlus | 7.0.7 | Excel dosyası oluşturma |

---

## 🔗 API Endpoints (İçeri Veri)

### Eksik İşlemleri
```
GET    /Eksik/SubeListe              Şubenin eksiklerini göster
GET    /Eksik/Create                 Yeni eksik formu
POST   /Eksik/Create                 Yeni eksik kaydet
GET    /Eksik/UrunAra?query=...      AJAX - Ürün arama
GET    /Eksik/BarkodAra?barkod=...   AJAX - Barkod arama
POST   /Eksik/TopluKaydet            Toplu eksik kaydı
GET    /Eksik/Gecmis                 Eksik geçmişi
```

### Sevkiyat İşlemleri
```
GET    /Sevkiyat                          Sevk bekleyenleri listele
POST   /Sevkiyat/SevkEt                   Sevk çıkışı yap
GET    /Sevkiyat/SubeOnay                 Şube onay sayfası
POST   /Sevkiyat/OnayEt                   Sevkiyatı onayla
POST   /Sevkiyat/Reddet                   Sevkiyatı reddet
GET    /Sevkiyat/ExportBekleyenEksikler   Excel'e aktar
```

### Admin İşlemleri
```
GET    /Admin/Subeler                    Şubeleri yönet
GET    /Admin/Urunler                    Ürünleri yönet
GET    /Admin/Kullanicilar               Kullanıcıları yönet
POST   /Admin/TopluUrunYukle             CSV/Excel ürün yükle
```

### Raporlar
```
GET    /Rapor/Index                     Eksik istatistikleri
GET    /RaporSts/Index                  STS raporları
```

---

## 📝 Veritabanı Sorguları Örnekleri

### Sevk Bekleyen Eksikleri Getir
```sql
SELECT e.Id, e.SiparisNo, u.Ad as UrunAdi, s.Ad as SubeAdi, 
       e.Miktar, e.AcilMi, e.GeciktiMi, e.GirisTarihi
FROM stk_EksikKaydi e
JOIN stk_Urun u ON e.UrunId = u.Id
JOIN stk_Sube s ON e.SubeId = s.Id
WHERE e.Durum = 'Bekliyor'
ORDER BY e.GeciktiMi DESC, e.AcilMi DESC, e.GirisTarihi ASC;
```

### Sevkiyat Geçmişi
```sql
SELECT sv.*, e.Id as EksikId, u.Ad as UrunAdi, s.Ad as SubeAdi
FROM stk_Sevkiyat sv
JOIN stk_EksikKaydi e ON sv.EksikKaydiId = e.Id
JOIN stk_Urun u ON e.UrunId = u.Id
JOIN stk_Sube s ON e.SubeId = s.Id
ORDER BY sv.SevkTarihi DESC;
```

### En Çok Eksik Ürünler
```sql
SELECT u.Ad, u.Birim, COUNT(*) as Adet
FROM stk_EksikKaydi e
JOIN stk_Urun u ON e.UrunId = u.Id
WHERE e.HaftaNo = @HaftaNo
GROUP BY u.Id, u.Ad, u.Birim
ORDER BY Adet DESC
LIMIT 10;
```

---

## 🛠️ Sık Kullanılan Methodlar

### Services/DbConnectionFactory.cs
```csharp
// Bağlantı oluştur ve aç
var conn = await _dbFactory.CreateConnectionAsync();

// Sorgu yürüt ve sonuç al
using (var reader = await cmd.ExecuteReaderAsync())
{
    while (await reader.ReadAsync())
    {
        // Veri işle
    }
}
```

### Hafta Numarası Hesapla
```csharp
private string GetHaftaNo()
{
    var bugun = DateTime.Now;
    var cilti = System.Globalization.CultureInfo.GetCultureInfo("tr-TR");
    var haftaNo = cilti.Calendar.GetWeekOfYear(bugun, 
        System.Globalization.CalendarWeekRule.FirstDay, 
        DayOfWeek.Monday);
    return $"W{haftaNo:D2}";
}
```

### Şifre Hashle
```csharp
var hash = BCrypt.Net.BCrypt.HashPassword(sifre);
var dogruMu = BCrypt.Net.BCrypt.Verify(sifre, hash);
```

---

## 📋 Views Listesi

### STS Modülü Views

```
Views/STS/
├── Account/
│   ├── Login.cshtml              STS kullanıcı girişi
│   └── StsLogin.cshtml           STS giriş formu
├── Home/
│   └── Index.cshtml              Ana sayfa
├── Eksik/
│   ├── SubeListe.cshtml          Şubenin eksikleri
│   ├── Create.cshtml             Yeni eksik formu
│   └── Gecmis.cshtml             Eksik geçmişi
├── Sevkiyat/
│   ├── Index.cshtml              Sevk bekleyenleri + geçmişi
│   └── SubeOnay.cshtml           Şube onay sayfası
├── Siparis/
│   ├── FabrikaListe.cshtml       Fabrika siparişleri
│   └── Durum.cshtml              Sipariş durum güncelle
├── Admin/
│   ├── Subeler.cshtml            Şube yönetimi
│   ├── Urunler.cshtml            Ürün yönetimi
│   └── Kullanicilar.cshtml       Kullanıcı yönetimi
├── RaporSts/
│   └── GeçmisHareketler.cshtml  Raporlar
└── Shared/
    ├── _Layout.cshtml            Ana layout
    └── _Menu.cshtml              Menü
```

---

## 🔒 Güvenlik Uygulamaları

1. **Session Kontrolleri**: Her aksiyonda rol ve yetki denetimi
2. **SQL Injection Koruması**: MySqlCommand parametreleri kullanılıyor
3. **Şifre Hashing**: BCrypt.Net-Next ile güvenli şifreleme
4. **HTTPS**: Development'ta yapılandırılmış
5. **CORS**: Temel yapı mevcut

---

## 📊 Raporlama ve İstatistikler

### Sunulan Raporlar
1. **Haftalık Eksik Trendi**: Tarih bazında eksik sayıları
2. **En Çok Eksik Ürünler**: Top 10 sıralaması
3. **Geç Giren Şubeler**: Pazartesi 17:00 sonrası kayıtlar
4. **Sevkiyat Durumları**: Duruma göre dağılım

---

## 🐛 Debugging ve Loglama

### Hata Yönetimi
```csharp
try
{
    // İş mantığı
}
catch (Exception ex)
{
    return BadRequest($"Hata: {ex.Message}");
}
```

### Loglama
- **Audit Log**: stk_HareketLog tablosunda kaydedilir
- **Exception Handling**: Try-catch ile HttpStatusCode dönülür

---

## 📈 İyileştirme Alanları

- [ ] Entity Framework Core'a geçiş
- [ ] Unit test yazılması
- [ ] Daha ayrıntılı logging
- [ ] API rate limiting
- [ ] Redis cache
- [ ] Asyn/await optimizasyonları
- [ ] MVC'den Minimal API'ye geçiş

---

## 📞 İletişim ve Destek

**Veritabanı Bilgileri**:
- Server: 94.73.145.55
- Database: u2636310_dbE97
- User: u2636310_userE97
- Port: 3306 (Default MySQL)

**Konfigürasyon Dosyaları**:
- `appsettings.json` - Bağlantı dizesi
- `appsettings.Development.json` - Development ayarları
- `launchSettings.json` - Startup ayarları

---

## 📄 Sürüm Geçmişi

| Versiyon | Tarih | Değişiklikler |
|----------|-------|---------------|
| 1.0.0 | 11.05.2026 | İlk sürüm - Temel STS modülü |
| 1.1.0 | 11.05.2026 | Excel export özelliği eklendi |

---

## ✅ Kontrol Listesi - Yeni Özellik Eklendiğinde

- [ ] Controller action'ı yazıldı
- [ ] View dosyası oluşturuldu
- [ ] Database migration yapıldı
- [ ] Rol yetkileri kontrol edildi
- [ ] Exception handling eklendi
- [ ] SQL injection koruması var
- [ ] README.md güncellendi
- [ ] Audit log entegresi yapıldı (varsa)
- [ ] Test edildi

---

**Son Güncelleme**: 11 Mayıs 2026
**Durum**: Aktif Geliştirme
