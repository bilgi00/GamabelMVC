﻿# Uygulama Degisiklik Ozeti (TR)

Bu dosya, son revizyonlarda yapilan ana teknik degisikliklerin kisa ozetidir.

## PRS / Hizli Mesai Girisi
- View yolu PRS dizinine netlendi: `Views/PRS/HizliMesaiGirisi/Index.cshtml`
- SQL akisi `mesai_kayitlari` kolon setine uyarlandi.
- `KayitEkle` null model kontrolu eklendi.
- Tarih parse kaynakli dizi tasmasi giderildi.
- Bos hucrelerde varsayilan `X` kaldirildi.
- Popup aciklama kaydi sadelelestirildi:
  - `Mesai Kodu` artik aciklamaya concat edilmiyor.
  - Sadece `Aciklama` verisi DB'ye yaziliyor.

## Dev Tooling
- `dev-tools.ps1` automatic variable cakismalari temizlendi:
  - `Profile` -> `LaunchProfile`
  - `DotnetArgs` -> `DotnetArguments`
- Rebuild/run akisinda kilit hatalarini azaltmak icin stop->build->run sirasi standardize edildi.

## Program ve Routing
- Razor view location formatlari duzeltildi.
- PRS/STS klasor yapisina uygun view arama devam ediyor.

## Dokuman Temizligi
- Eski/uzun ve guncel akisla uyumsuz bolumler sadelelestirildi.
- Guncel dizin yapisi README'ye eklendi.

## Arsiv Kaydi (7 Mayis 2026)
- Paket temizligi:
  - `gamabelmvc.csproj` icinden `ClosedXML` paketi kaldirildi.
  - `Controllers/AdminController.cs` icindeki `using ClosedXML.Excel;` kaldirildi.
- STS Urun Yonetimi:
  - `UrunDuzenle` (GET), `UrunGuncelle` (POST), `SilUrun` (POST) endpointleri eklendi.
  - `Views/STS/Admin/Urunler.cshtml` duzenle/sil modal ve JS akisiyla guncellendi.
  - `Models/STS/StsUrun.cs` modeline `Firma` alani eklendi.
- Gecis donemi notu:
  - `UrunTopluYukle` ve `FirmaYukle` endpointleri bir sure placeholder cevap dondurecek sekilde tutuldu.
- Durum:
  - O tarih itibariyla derleme calisabilir durumdaydi ve uygulama `localhost:5010` uzerinden test edilmisti.
