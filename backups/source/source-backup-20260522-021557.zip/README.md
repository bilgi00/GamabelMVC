﻿# Gamabel MVC

Gamabel MVC, iki ana alan iceren bir ASP.NET Core 9.0 uygulamasidir:
- PRS (Personel / Mesai / Puantaj)
- STS (Sevkiyat Takip Sistemi)

## Guncel Teknoloji Bilgisi
- .NET: 9.0
- Veritabani: MySQL (MySqlConnector)
- UI: Razor Views + Bootstrap
- Excel: EPPlus

## Guncel Dizin Yapisi

```text
gamabelmvc/
|-- Controllers/
|   |-- AccountController.cs
|   |-- AdminController.cs
|   |-- DokumantasyonController.cs
|   |-- HomeController.cs
|   |-- PRS/
|   |   |-- HizliMesaiGirisiController.cs
|   |   |-- KullaniciController.cs
|   |   |-- MesaiController.cs
|   |   |-- PuantajController.cs
|   |   |-- ResmiTatilController.cs
|   |   `-- SikayetController.cs
|   `-- STS/
|       |-- EksikController.cs
|       |-- RaporController.cs
|       |-- RaporStsController.cs
|       |-- SevkiyatController.cs
|       `-- SiparisController.cs
|-- Models/
|   |-- ErrorViewModel.cs
|   |-- StsLoginViewModel.cs
|   |-- UrunTopluYukleResult.cs
|   |-- PRS/
|   `-- STS/
|-- Services/
|   `-- DbConnectionFactory.cs
|-- Views/
|   |-- Account/
|   |-- Dokumantasyon/
|   |-- Home/
|   |-- PRS/
|   |   `-- HizliMesaiGirisi/
|   |       |-- Index.cshtml
|   |       `-- Admin.cshtml
|   |-- STS/
|   `-- Shared/
|-- wwwroot/
|-- sql/
|-- Program.cs
|-- dev-tools.ps1
|-- HIZLI_MESAI_GIRISI_KILAVUZ.md
|-- FILTER_FEATURE_DOCUMENTATION.md
`-- IMPLEMENTATION_SUMMARY_TR.md
```

## Son Guncellemeler (Mayis 2026)
- Hizli Mesai Girisi view yolu PRS altina netlendi.
- `Index was outside the bounds of the array` hatasi, tarih parse guvenligi ile giderildi.
- Bos gun hucrelerindeki varsayilan `X` kaldirildi.
- Popup aciklama kaydi duzeltildi: `Mesai Kodu` artik aciklamaya yazilmiyor, sadece `Aciklama` alani DB'ye gidiyor.
- `KayitEkle` icin null model guard eklendi.
- `dev-tools.ps1` icinde PowerShell automatic variable cakismalari giderildi (`LaunchProfile`, `DotnetArguments`).

## Arsiv Notu (7 Mayis 2026)
- ClosedXML bagimliligi kaldirildi.
- STS Urun Yonetimi tarafinda duzenle/sil akisi aktif hale getirildi (`UrunDuzenle`, `UrunGuncelle`, `SilUrun`).
- `StsUrun` modeline `Firma` alani eklendi.
- Excel/Firma toplu yukleme endpointleri placeholder moda alinmisti (o donem gecis notu).

## Calistirma

```powershell
.\dev-tools.ps1 -Action stop
.\dev-tools.ps1 -Action rebuild
.\dev-tools.ps1 -Action run -Port 5010
```

Not: Eger kilit hatasi gorulurse (`MSB3021`, `MSB3027`), once `stop` calistirilmalidir.

## Dokumanlar
- Hizli Mesai modulu: `HIZLI_MESAI_GIRISI_KILAVUZ.md`
- STS filtre ozeti: `FILTER_FEATURE_DOCUMENTATION.md`
- Uygulama degisiklik ozeti: `IMPLEMENTATION_SUMMARY_TR.md`
