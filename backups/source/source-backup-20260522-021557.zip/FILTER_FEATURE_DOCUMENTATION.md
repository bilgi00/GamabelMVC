﻿# STS Sevkiyat Filtre Ozelligi - Guncel Not

Bu dokuman STS Sevkiyat sayfasindaki filtre davranisinin kisa ve guncel ozetidir.

## Ozellikler
- Bolum + firma filtreleme
- Manuel filtre yenileme
- Session ile son secimlerin korunmasi
- Secili filtrelerin UI'da badge/alert olarak gosterimi
- Excel export'un secili filtreyle calismasi

## Teknik Noktalar
- Controller: `Controllers/STS/SevkiyatController.cs`
- View: `Views/STS/Sevkiyat/Index.cshtml`
- Parametreler trim edilerek sorguya aktarilir.
- SQL tarafi parametreli sorgu ile calisir.

## Not
Bu dokuman sadeleştirilmis ozet olarak tutulur. Ayrintili is akislari ve sistem genel yapisi icin `README.md` kullanilmalidir.
